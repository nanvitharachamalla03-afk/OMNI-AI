
import requests

OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL_NAME = "llama3.2:1b"


def get_ai_response(user_input, conversation_history=None):
    """Generate an answer using a local Ollama model."""

    messages = [
        {
            "role": "system",
            "content": (
                "You are OMNI AI, a helpful AI assistant. "
                "Answer clearly and explain difficult concepts "
                "in simple English."
            ),
        }
    ]

    # Include previous messages for conversational context.
    if conversation_history:
        for message in conversation_history:
            role = message.get("role")
            content = message.get("content", "")

            if role in ("user", "assistant") and content:
                messages.append({
                    "role": role,
                    "content": content,
                })

    # Add the current question only if it isn't already included.
    if not (
        conversation_history
        and conversation_history[-1].get("role") == "user"
        and conversation_history[-1].get("content") == user_input
    ):
        messages.append({
            "role": "user",
            "content": user_input,
        })

    try:
        response = requests.post(
            OLLAMA_URL,
            json={
                "model": MODEL_NAME,
                "messages": messages,
                "stream": False,
            },
            timeout=180,
        )

        response.raise_for_status()
        result = response.json()

        return result["message"]["content"]

    except requests.exceptions.ConnectionError:
        return (
            "Ollama is not running. Please open Ollama "
            "and try again."
        )

    except requests.exceptions.Timeout:
        return (
            "The model is taking too long to respond. "
            "Try a shorter question or a smaller model."
        )

    except requests.exceptions.RequestException as error:
        return f"Local AI connection error: {error}"

    except (KeyError, ValueError):
        return "OMNI AI received an unexpected response from Ollama."