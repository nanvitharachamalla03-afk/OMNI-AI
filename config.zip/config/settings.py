import os
from dotenv import load_dotenv

load_dotenv()

APP_NAME = "OMNI AI"

APP_VERSION = "1.0.0"

DEBUG = True

API_KEY = os.getenv("API_KEY")